---
name: researching-ai-news
description: Research and compile the latest AI news from across the industry. Use this skill when asked to find AI news, get AI updates, research what's happening in AI, check for AI announcements, or gather intelligence on AI companies. Triggers include requests for "AI news", "latest AI developments", "what's new in AI", "AI industry updates", or news about specific AI companies (OpenAI, Anthropic, Google, Microsoft, Meta, Amazon, Nvidia, xAI, Mistral, Cohere).
---

# Researching AI News

Research and compile AI news from across the industry, covering major companies and emerging trends.

## Companies to Track

**Frontier Labs:**
- OpenAI
- Anthropic
- Google DeepMind / Google AI
- Meta AI / FAIR
- xAI

**Tech Giants:**
- Microsoft AI
- Amazon AWS AI / Bedrock
- Nvidia

**AI Startups:**
- Mistral AI
- Cohere
- Other emerging labs

## Topics to Cover

1. **Product launches & updates** - New models, features, API changes
2. **Research breakthroughs** - Papers, benchmarks, capabilities
3. **Regulations & policy** - Government actions, safety initiatives, legal developments
4. **Industry trends** - Funding, partnerships, acquisitions, market moves

## Research Workflow

### Step 1: Run Perplexity Searches

Use the Perplexity MCP tools for comprehensive, citation-rich results:

**Primary tool: `mcp__perplexity__perplexity_search`**
- Best for quick, targeted queries with ranked results
- Returns titles, URLs, snippets, and metadata
- Use `max_results: 10` for comprehensive coverage

**Deep research: `mcp__perplexity__perplexity_research`**
- Use for complex topics requiring synthesis across sources
- Returns comprehensive analysis with citations
- Best for industry trends and regulatory developments

### Search Queries

Run these searches in parallel using `mcp__perplexity__perplexity_search`:

```
Company news (run in parallel):
- "OpenAI announcement news today"
- "Anthropic Claude news today"
- "Google Gemini AI news today"
- "Microsoft AI Copilot news today"
- "Meta Llama AI news today"
- "Nvidia AI news today"
- "xAI Grok news today"
- "Amazon AWS Bedrock AI news today"
- "Mistral AI news today"

Industry topics (run in parallel):
- "AI regulation policy news today"
- "AI research breakthrough news today"
- "AI startup funding investment news today"
```

For deeper analysis, use `mcp__perplexity__perplexity_research` with:
```json
{
  "messages": [
    {"role": "user", "content": "What are the most significant AI industry developments in the last 24 hours? Include product launches, research breakthroughs, regulatory changes, and major funding announcements."}
  ]
}
```

### Step 2: Filter for Recency

Only include stories from the last 24 hours. Perplexity provides up-to-date results with timestamps.

### Step 3: Compile Results

Format output as bullet points with source links:

```markdown
## AI News - [Date]

### Company Updates
- **[Company]**: [Brief summary of news] ([Source](url))
- **[Company]**: [Brief summary of news] ([Source](url))

### Product Launches
- [Product/feature description] ([Source](url))

### Research & Breakthroughs
- [Research summary] ([Source](url))

### Regulation & Policy
- [Policy development] ([Source](url))

### Industry Trends
- [Trend/funding/partnership] ([Source](url))
```

### Step 4: Prioritize

Order stories by significance:
1. Major model releases or capabilities
2. Significant policy/regulatory changes
3. Large funding rounds or acquisitions
4. Research breakthroughs
5. Product updates and features

## Output Guidelines

- Keep summaries to 1-2 sentences per story
- Always include source links
- Group related stories together
- Note if a category has no news ("No significant updates")
- Flag breaking/developing stories

## Perplexity MCP Tools Reference

| Tool | Use Case |
|------|----------|
| `mcp__perplexity__perplexity_search` | Quick searches, specific company news, targeted queries |
| `mcp__perplexity__perplexity_research` | Deep analysis, trend synthesis, comprehensive reports |
| `mcp__perplexity__perplexity_ask` | Follow-up questions, clarifications |

### Search Tips

- Use company + product names for precision ("Claude 3.5", "GPT-4", "Gemini 2.0")
- Add "today" or current date to queries for recency
- Run company searches in parallel for efficiency
- Use `perplexity_research` for synthesizing trends across multiple sources
- Perplexity automatically includes citations - preserve these in output
